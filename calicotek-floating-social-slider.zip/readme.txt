=== CaliCoTek Floating Social Slider ===
Contributors: (ModManMatt) http://CaliCoTek.com
Donate link: http://calicotek.com/donate
Tags: Support, Calicotek, CaliCoTek, calicotek, CCT Floating Social Slider, Social, Facebook, fb, twitter, social slider
Requires at least: 3.3
Tested up to: 3.6
Stable tag: 1.5.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This Plugin Adds A Easy/Free Floating Social Sliders to any WP Website. Includes Facebook, Linkedin, Pinterest, Twitter(Broken), Google+ and Email.
== Description ==

this simple plugin adds a social slider to the sides top or bottom of any website so far it supports facebook, twitter, google plus, and site email... when the user of the site hovers over the social sliders they slide out using java script,.. social profiles can be configured via a admin settings page...
Everything is working now for most part can position left and right and add options that function :)
== Installation ==

1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Add your social page info to the settings page to link the sliders to your pages... You can access the settings for this plugin under settings tab of wp admin dashboard.
4. All Done :)

== Frequently asked questions ==

= Does this plugin interfere with other plugins? =

I dont think so, but it is a new first time attempt at a plugin.
issues or errors Reported yet? some issues with different themes reported. i will look into this for future versions.

== Screenshots ==

1. Plugin Front Side slider Screenshot.
2. Plugin Front Side slider Screenshot Closeup Facebook.
3. Plugin Front Side slider Screenshot Closeup Twitter.
4. Plugin settings Page Screenshot.

== Changelog ==

= 1.5.2 =
* Added Codes, images and styles for linkedin. (working)
* Added Codes, images and styles for Pinterest. (Not Working)
* Added Pinterest Slider. (working)
* Updated Settings PageNotes.
* Fixed Faceboo0k Slider Dimensions to not chop off faces.
= 1.5.1 =
* Turned Off Twitter Slider due to new twitter update no longer supporting java script it now requires twitter dev app to function. working on a fix.
= 1.5.0 =
* reverted back to v1.4.6 and recoded changes to fix the brake... working again with updates and positioning.. will finish the toggle swiches soon.
= 1.4.9 =
* Fixed Slider Positioning for left and right
* icon images are also fixed so they show in the correct mirror form for either side placement :)
= 1.4.8 =
* Recommitted for bugs :( yuk
= 1.4.7 =
* Added Options for Pinterest and Linkdin (beta)
* Started adding Settings Check box setting on off field (beta)
* Updated Notations and settings help notes
* Cleaned Up Settings Screen and logo 
* Updated Screen Shots for settings page
= 1.4.6 =
* Left and Right Option Working for most part still a little css to play with but functional.4.6
* Facebook And Twitter Fully Working :)
* Twitter option now works from options menu
= 1.4.5 = 
* FAcebook is working from settings page and to change twitte.4r location it's notated under fss-code.php
= 1.4.4 = 
* Facebook setting profile from settings page should work now
* Fixed Screen Shots
= 1.4.3 = 
* Recommited with new screenshots and updated readme
= 1.4.2 = 
* Themed to Be More Wordpress Style
* Updaded change log
* updated screen shots
* Added Screen Position Option
* Update Options Page
= 1.4.1 = 
* Added Plugin Options Page to WP Admin 
* Added Plugin Options Menu to WP Admin settings tab.
= 1.1 =
* Fixed a few small errors from repository upload and config.
= 1.0 =
* Added Main System and settings plugin works with no errors but still needs to have the settings part configured as it doesnt work yet you would have to edit the plugin page to add the settings manualy this will be fixed in next update..

== Upgrade notice ==

1. Finish configuration of settings page to make functional.
2. Add more Social Options with check boxes to turn on and off the social sliders wanted.
3. Move Slider To Different Sides of Screen IE..(left, right, top and bottom) from plugin options page

== Future Planned Features ==
* Make Settings Page Data Values Function
* Move Slider To Different Sides of Screen IE..(left, right, top and bottom) from plugin options page
* Add Digg Social Slider options
* Add LinkedIn Social Slider options
* Add Pinterest Social Slider options
* Add MySpace Social Slider options
* Add Instagram Social Slider options
* Add Foursquare Social Slider options
* Taking Request on more social slider options :) 

